package inassGaby.beans;

public class Equipe {

	private int id;

	private Joueur joueur1;
	private Joueur joueur2;

	private int score;

}
