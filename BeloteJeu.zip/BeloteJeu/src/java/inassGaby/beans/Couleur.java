package inassGaby.beans;

/*les couleurs de la carte de belote*/
public enum Couleur {
	pique, trefle, carreau, coeur
}